# AgentCross — Physical Operations Conflict Guard

A runnable local MVP demonstrating conflict detection for requests made by multiple AI/business agents. It flags overlapping bookings for the same resource, recommends a free time slot, blocks approval of conflicted requests, and records an audit trail.

## Important hackathon fit note

This repository is a software MVP. By itself, it does **not** meet the CraftifAI Physical AI Hackathon hardware requirement:
- **PipeGen track:** requires a full PipeGen pipeline, a TensorRT engine, and a live run on a compatible NVIDIA GPU machine or Jetson, with actionable output.
- **FirmGen track:** requires a PRD-driven firmware build flashed to a physical ESP32/STM32 board, acceptance evidence, and a traceability report.

Use the app as your conflict-management layer only if you can genuinely integrate and demonstrate one of those required tracks. Ask the organizers whether your laptop-only prototype can be accepted or whether hardware access is available. Do not claim that the physical track is complete without the required evidence.

## Features

- Dashboard summary cards
- Sample production and maintenance requests that intentionally conflict
- Create a request from the browser
- Same-resource overlapping-time detection
- Approval blocked while a request has active conflicts
- Suggested free slot search (30-minute increments, up to 24 hours)
- Reject action and audit trail
- SQLite database created locally on first run
- No API key or cloud account required for this MVP

## Run on Windows 10/11

1. Install Python 3.11 or newer from https://www.python.org/downloads/ and enable **Add Python to PATH** during installation.
2. Extract this ZIP file.
3. Open the extracted `AgentCross` folder in File Explorer.
4. Click the address bar, type `cmd`, and press Enter.
5. Run these commands:

```powershell
py -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
uvicorn app.main:app --reload
```

6. Open http://127.0.0.1:8000 in your browser.
7. API documentation is available at http://127.0.0.1:8000/docs.
8. To stop the server, focus the terminal and press `Ctrl+C`.

If `py` is not recognized, try `python` instead. If activation is blocked by PowerShell policy, use Command Prompt (`cmd`) as above.

## Demo walkthrough

1. Open the dashboard. The sample Production Agent and Maintenance Agent requests overlap on Machine A.
2. Show the conflict count and the conflict details.
3. Click **Suggest free slot** to display a possible later time.
4. Try **Approve** on a conflicted request. It should be blocked.
5. Create a request for a different resource/time to show the no-conflict path.
6. Approve the conflict-free request and show the audit history.
7. Use **Reset demo** to restore sample data.

## Test data and limitations

- The preloaded requests use October 18, 2026 timestamps for a repeatable demo.
- Times are stored as local ISO datetime strings; this prototype assumes consistent local time zones and same-day comparisons.
- The alternative finder searches forward in 30-minute increments for up to 24 hours.
- This MVP does not call a real LLM, control a physical machine, authenticate users, or provide production-grade authorization. The “agents” are simulated sample request sources.
- Do not connect this prototype to real equipment or use it for safety-critical decisions.

## Suggested next integrations (only if time and access permit)

- PipeGen: actual camera-based event JSON/MQTT feed can become a resource lock/alert input, but the required PipeGen pipeline and TensorRT evidence must still be supplied.
- FirmGen: define a PRD for a physical ESP32/STM32 warning device, flash real hardware, and provide UART/monitor acceptance evidence plus the FirmGen traceability report.
