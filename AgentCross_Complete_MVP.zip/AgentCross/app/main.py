from datetime import datetime, timedelta
from pathlib import Path
import json
import sqlite3
import uuid

from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
DB_PATH = ROOT / "agentcross.db"
app = FastAPI(title="AgentCross", description="Conflict detection and approval for AI-agent operations", version="1.0.0")


def connect():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with connect() as con:
        con.execute("""
        CREATE TABLE IF NOT EXISTS requests (
            id TEXT PRIMARY KEY,
            agent TEXT NOT NULL,
            resource TEXT NOT NULL,
            start_time TEXT NOT NULL,
            end_time TEXT NOT NULL,
            purpose TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL
        )""")
        con.execute("""
        CREATE TABLE IF NOT EXISTS audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            request_id TEXT,
            event TEXT NOT NULL,
            detail TEXT NOT NULL,
            created_at TEXT NOT NULL
        )""")
        count = con.execute("SELECT COUNT(*) FROM requests").fetchone()[0]
        if count == 0:
            now = datetime.now().isoformat(timespec="seconds")
            seed = [
                ("demo-production", "Production Agent", "Machine A", "2026-10-18T14:00", "2026-10-18T16:00", "Produce batch 42", "pending", now),
                ("demo-maintenance", "Maintenance Agent", "Machine A", "2026-10-18T15:00", "2026-10-18T16:00", "Scheduled maintenance", "pending", now),
                ("demo-quality", "Quality Agent", "Inspection Station", "2026-10-18T13:00", "2026-10-18T13:45", "Inspect completed batch", "pending", now),
            ]
            con.executemany("INSERT INTO requests VALUES (?, ?, ?, ?, ?, ?, ?, ?)", seed)
            con.execute("INSERT INTO audit(request_id,event,detail,created_at) VALUES(?,?,?,?)",
                        ("demo-production", "DEMO_DATA_LOADED", "Sample scheduling requests loaded on first run.", now))


init_db()


class RequestIn(BaseModel):
    agent: str = Field(min_length=2, max_length=80)
    resource: str = Field(min_length=2, max_length=80)
    start_time: datetime
    end_time: datetime
    purpose: str = Field(min_length=3, max_length=300)


def dt(value):
    return datetime.fromisoformat(value)


def as_dict(row):
    d = dict(row)
    d["conflicts"] = []
    return d


def get_requests():
    with connect() as con:
        rows = con.execute("SELECT * FROM requests ORDER BY start_time").fetchall()
    requests = [as_dict(r) for r in rows]
    by_id = {r["id"]: r for r in requests}
    for i, a in enumerate(requests):
        if a["status"] == "rejected":
            continue
        for b in requests[i + 1:]:
            if b["status"] == "rejected":
                continue
            if a["resource"].casefold() == b["resource"].casefold():
                if dt(a["start_time"]) < dt(b["end_time"]) and dt(b["start_time"]) < dt(a["end_time"]):
                    a["conflicts"].append(b["id"])
                    b["conflicts"].append(a["id"])
    return requests


def audit(request_id, event, detail):
    with connect() as con:
        con.execute("INSERT INTO audit(request_id,event,detail,created_at) VALUES(?,?,?,?)",
                    (request_id, event, detail, datetime.now().isoformat(timespec="seconds")))


def find_alternative(target, all_requests):
    start = dt(target["start_time"])
    end = dt(target["end_time"])
    duration = end - start
    resource = target["resource"].casefold()
    others = [r for r in all_requests if r["id"] != target["id"] and r["status"] != "rejected"
              and r["resource"].casefold() == resource]
    # Search forward in 30-minute increments for a free slot within the next 24 hours.
    candidate = start
    for _ in range(48):
        candidate += timedelta(minutes=30)
        candidate_end = candidate + duration
        overlap = any(candidate < dt(r["end_time"]) and dt(r["start_time"]) < candidate_end for r in others)
        if not overlap:
            return {"start_time": candidate.isoformat(timespec="minutes"),
                    "end_time": candidate_end.isoformat(timespec="minutes")}
    return None


@app.get("/", response_class=HTMLResponse)
def home():
    return (ROOT / "index.html").read_text(encoding="utf-8")


@app.get("/api/health")
def health():
    return {"status": "ok", "app": "AgentCross", "version": "1.0.0"}


@app.get("/api/requests")
def list_requests():
    return get_requests()


@app.get("/api/summary")
def summary():
    requests = get_requests()
    conflict_ids = set()
    for r in requests:
        if r["conflicts"]:
            conflict_ids.add(r["id"])
    return {
        "total_requests": len(requests),
        "conflicted_requests": len(conflict_ids),
        "pending": sum(r["status"] == "pending" for r in requests),
        "approved": sum(r["status"] == "approved" for r in requests),
        "conflicts": [
            {"request_id": r["id"], "agent": r["agent"], "resource": r["resource"],
             "start_time": r["start_time"], "end_time": r["end_time"],
             "conflicting_request_ids": r["conflicts"]}
            for r in requests if r["conflicts"]
        ]
    }


@app.post("/api/requests", status_code=201)
def create_request(payload: RequestIn):
    if payload.end_time <= payload.start_time:
        raise HTTPException(400, "End time must be after start time.")
    rid = str(uuid.uuid4())[:8]
    created = datetime.now().isoformat(timespec="seconds")
    with connect() as con:
        con.execute("INSERT INTO requests VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                    (rid, payload.agent.strip(), payload.resource.strip(),
                     payload.start_time.isoformat(timespec="minutes"),
                     payload.end_time.isoformat(timespec="minutes"),
                     payload.purpose.strip(), "pending", created))
    audit(rid, "REQUEST_CREATED", f"{payload.agent} requested {payload.resource}.")
    all_requests = get_requests()
    new = next(r for r in all_requests if r["id"] == rid)
    return {"request": new, "has_conflict": bool(new["conflicts"]),
            "alternative": find_alternative(new, all_requests) if new["conflicts"] else None}


@app.get("/api/requests/{request_id}/alternative")
def alternative(request_id: str):
    requests = get_requests()
    target = next((r for r in requests if r["id"] == request_id), None)
    if not target:
        raise HTTPException(404, "Request not found.")
    return {"request_id": request_id, "alternative": find_alternative(target, requests)}


@app.post("/api/requests/{request_id}/approve")
def approve(request_id: str):
    requests = get_requests()
    target = next((r for r in requests if r["id"] == request_id), None)
    if not target:
        raise HTTPException(404, "Request not found.")
    if target["conflicts"]:
        raise HTTPException(409, "Approval blocked: resolve the resource/time conflict first.")
    if target["status"] == "rejected":
        raise HTTPException(409, "Rejected requests cannot be approved.")
    with connect() as con:
        con.execute("UPDATE requests SET status='approved' WHERE id=?", (request_id,))
    audit(request_id, "APPROVED", "Human approved a conflict-free request.")
    return {"ok": True, "message": "Request approved.", "request_id": request_id}


@app.post("/api/requests/{request_id}/reject")
def reject(request_id: str):
    with connect() as con:
        row = con.execute("SELECT * FROM requests WHERE id=?", (request_id,)).fetchone()
        if not row:
            raise HTTPException(404, "Request not found.")
        con.execute("UPDATE requests SET status='rejected' WHERE id=?", (request_id,))
    audit(request_id, "REJECTED", "Human rejected the request.")
    return {"ok": True, "message": "Request rejected.", "request_id": request_id}


@app.post("/api/reset-demo")
def reset_demo():
    with connect() as con:
        con.execute("DELETE FROM requests")
        con.execute("DELETE FROM audit")
        now = datetime.now().isoformat(timespec="seconds")
        seed = [
            ("demo-production", "Production Agent", "Machine A", "2026-10-18T14:00", "2026-10-18T16:00", "Produce batch 42", "pending", now),
            ("demo-maintenance", "Maintenance Agent", "Machine A", "2026-10-18T15:00", "2026-10-18T16:00", "Scheduled maintenance", "pending", now),
            ("demo-quality", "Quality Agent", "Inspection Station", "2026-10-18T13:00", "2026-10-18T13:45", "Inspect completed batch", "pending", now),
        ]
        con.executemany("INSERT INTO requests VALUES (?, ?, ?, ?, ?, ?, ?, ?)", seed)
    audit("demo-production", "DEMO_RESET", "Demo requests reset.")
    return {"ok": True, "message": "Demo data reset."}


@app.get("/api/audit")
def audit_log():
    with connect() as con:
        rows = con.execute("SELECT * FROM audit ORDER BY id DESC LIMIT 100").fetchall()
    return [dict(r) for r in rows]
