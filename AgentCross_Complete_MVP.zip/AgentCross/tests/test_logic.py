from datetime import datetime

def overlaps(a_start, a_end, b_start, b_end):
    return a_start < b_end and b_start < a_end

def test_overlapping_intervals():
    assert overlaps(datetime(2026, 10, 18, 14), datetime(2026, 10, 18, 16),
                    datetime(2026, 10, 18, 15), datetime(2026, 10, 18, 17))

def test_adjacent_intervals_do_not_overlap():
    assert not overlaps(datetime(2026, 10, 18, 14), datetime(2026, 10, 18, 15),
                        datetime(2026, 10, 18, 15), datetime(2026, 10, 18, 16))

def test_separate_resources_are_not_a_conflict():
    # Resource equality is checked before interval overlap in the application.
    assert "Machine A".casefold() != "Inspection Station".casefold()
